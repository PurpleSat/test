/* eslint-disable @typescript-eslint/ban-ts-comment, @typescript-eslint/no-explicit-any, react-hooks/exhaustive-deps, no-console, @next/next/no-img-element */

'use client';

import Artplayer from 'artplayer';
import Hls from 'hls.js';
import { Heart } from 'lucide-react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useEffect, useRef, useState } from 'react';

import {
  deleteFavorite,
  deletePlayRecord,
  deleteSkipConfig,
  generateStorageKey,
  getAllPlayRecords,
  getSkipConfig,
  isFavorited,
  saveFavorite,
  savePlayRecord,
  saveSkipConfig,
  subscribeToDataUpdates,
} from '@/lib/db.client';
import { SearchResult } from '@/lib/types';
import { getVideoResolutionFromM3u8, processImageUrl } from '@/lib/utils';

import EpisodeSelector from '@/components/EpisodeSelector';
import PageLayout from '@/components/PageLayout';
import { filterAdsFromM3U8 } from '@/lib/m3u8-ad-filter';

// 扩展 HTMLVideoElement 类型以支持 hls 属性
declare global {
  interface HTMLVideoElement {
    hls?: any;
  }
}

// Wake Lock API 类型声明
interface WakeLockSentinel {
  released: boolean;
  release(): Promise<void>;
  addEventListener(type: 'release', listener: () => void): void;
  removeEventListener(type: 'release', listener: () => void): void;
}

function PlayPageClient() {
  const router = useRouter();
  const searchParams = useSearchParams();

  // -----------------------------------------------------------------------------
  // 状态变量（State）
  // -----------------------------------------------------------------------------
  const [loading, setLoading] = useState(true);
  const [loadingStage, setLoadingStage] = useState<
    'searching' | 'preferring' | 'fetching' | 'ready'
  >('searching');
  const [loadingMessage, setLoadingMessage] = useState('正在搜索播放源...');
  const [error, setError] = useState<string | null>(null);
  const [detail, setDetail] = useState<SearchResult | null>(null);

  // 收藏状态
  const [favorited, setFavorited] = useState(false);

  // 跳过片头片尾配置 (全面接入云端同步配置)
  const [skipConfig, setSkipConfig] = useState<{
    enable: boolean;
    intro_time: number;
    outro_time: number;
  }>({
    enable: false,
    intro_time: 0,
    outro_time: 0,
  });
  const skipConfigRef = useRef(skipConfig);
  useEffect(() => {
    skipConfigRef.current = skipConfig;
  }, [skipConfig]);

  // 【核心防御状态】：防抖与防误伤标记
  const hasSkippedIntroRef = useRef(false);
  const hasSkippedOutroRef = useRef(false);

  // 去广告开关
  const [blockAdEnabled, setBlockAdEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const v = localStorage.getItem('enable_blockad');
      if (v !== null) return v === 'true';
    }
    return true;
  });
  const blockAdEnabledRef = useRef(blockAdEnabled);
  useEffect(() => {
    blockAdEnabledRef.current = blockAdEnabled;
  }, [blockAdEnabled]);

  // 视频基本信息
  const [videoTitle, setVideoTitle] = useState(searchParams.get('title') || '');
  const [videoYear, setVideoYear] = useState(searchParams.get('year') || '');
  const [videoCover, setVideoCover] = useState('');
  const [videoDoubanId, setVideoDoubanId] = useState(0);

  // 当前源和ID
  const [currentSource, setCurrentSource] = useState(
    searchParams.get('source') || ''
  );
  const [currentId, setCurrentId] = useState(searchParams.get('id') || '');

  // 搜索所需信息
  const [searchTitle] = useState(searchParams.get('stitle') || '');
  const [searchType] = useState(searchParams.get('stype') || '');

  // 是否需要优选
  const [needPrefer, setNeedPrefer] = useState(
    searchParams.get('prefer') === 'true'
  );
  const needPreferRef = useRef(needPrefer);
  useEffect(() => {
    needPreferRef.current = needPrefer;
  }, [needPrefer]);

  // 集数相关
  const [currentEpisodeIndex, setCurrentEpisodeIndex] = useState(0);

  const currentSourceRef = useRef(currentSource);
  const currentIdRef = useRef(currentId);
  const videoTitleRef = useRef(videoTitle);
  const videoYearRef = useRef(videoYear);
  const detailRef = useRef<SearchResult | null>(detail);
  const currentEpisodeIndexRef = useRef(currentEpisodeIndex);

  // 同步最新值到 refs
  useEffect(() => {
    currentSourceRef.current = currentSource;
    currentIdRef.current = currentId;
    detailRef.current = detail;
    currentEpisodeIndexRef.current = currentEpisodeIndex;
    videoTitleRef.current = videoTitle;
    videoYearRef.current = videoYear;
  }, [
    currentSource,
    currentId,
    detail,
    currentEpisodeIndex,
    videoTitle,
    videoYear,
  ]);

  // 切换集数时，重置片头片尾的跳过防抖状态
  useEffect(() => {
    hasSkippedIntroRef.current = false;
    hasSkippedOutroRef.current = false;
  }, [currentEpisodeIndex]);

  // 视频播放地址
  const [videoUrl, setVideoUrl] = useState('');

  // 总集数
  const totalEpisodes = detail?.episodes?.length || 0;

  // 用于记录是否需要在播放器 ready 后跳转到指定进度
  const resumeTimeRef = useRef<number | null>(null);
  // 上次使用的音量，默认 0.7
  const lastVolumeRef = useRef<number>(0.7);
  // 上次使用的播放速率，默认 1.0
  const lastPlaybackRateRef = useRef<number>(1.0);

  // 换源相关状态
  const [availableSources, setAvailableSources] = useState<SearchResult[]>([]);
  const [sourceSearchLoading, setSourceSearchLoading] = useState(false);
  const [sourceSearchError, setSourceSearchError] = useState<string | null>(null);

  // 优选和测速开关
  const [optimizationEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('enableOptimization');
      if (saved !== null) {
        try {
          return JSON.parse(saved);
        } catch (_e) {
          console.debug('解析 enableOptimization 配置失败', _e);
        }
      }
    }
    return true;
  });

  // 保存优选时的测速结果
  const [precomputedVideoInfo, setPrecomputedVideoInfo] = useState<
    Map<string, { quality: string; loadSpeed: string; pingTime: number }>
  >(new Map());

  // 折叠状态
  const [isEpisodeSelectorCollapsed, setIsEpisodeSelectorCollapsed] = useState(false);

  // 换源加载状态
  const [isVideoLoading, setIsVideoLoading] = useState(true);
  const [videoLoadingStage, setVideoLoadingStage] = useState<
    'initing' | 'sourceChanging'
  >('initing');

  // 播放进度保存相关
  const saveIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const lastSaveTimeRef = useRef<number>(0);

  const artPlayerRef = useRef<any>(null);
  const artRef = useRef<HTMLDivElement | null>(null);

  // Wake Lock 相关
  const wakeLockRef = useRef<WakeLockSentinel | null>(null);

  // -----------------------------------------------------------------------------
  // 工具函数（Utils）
  // -----------------------------------------------------------------------------

  // 播放源优选函数
  const preferBestSource = async (
    sources: SearchResult[]
  ): Promise<SearchResult> => {
    if (sources.length === 1) return sources[0];

    const MAX_CONCURRENT_TEST = 4;
    const allResults: Array<{
      source: SearchResult;
      testResult: { quality: string; loadSpeed: string; pingTime: number };
    } | null> = new Array(sources.length).fill(null);

    const testOne = async (index: number) => {
      const source = sources[index];
      try {
        if (!source.episodes || source.episodes.length === 0) return;
        const episodeUrl =
          source.episodes.length > 1 ? source.episodes[1] : source.episodes[0];
        const testResult = await getVideoResolutionFromM3u8(episodeUrl);
        allResults[index] = { source, testResult };
      } catch (_error) {
        allResults[index] = null;
      }
    };

    let cursor = 0;
    const workers = Array.from(
      { length: Math.min(MAX_CONCURRENT_TEST, sources.length) },
      async () => {
        while (cursor < sources.length) {
          const current = cursor++;
          await testOne(current);
        }
      }
    );
    await Promise.all(workers);

    const newVideoInfoMap = new Map<
      string,
      { quality: string; loadSpeed: string; pingTime: number; hasError?: boolean; }
    >();
    allResults.forEach((result, index) => {
      const source = sources[index];
      const sourceKey = `${source.source}-${source.id}`;
      if (result) newVideoInfoMap.set(sourceKey, result.testResult);
    });

    const successfulResults = allResults.filter(Boolean) as Array<{
      source: SearchResult;
      testResult: { quality: string; loadSpeed: string; pingTime: number };
    }>;

    setPrecomputedVideoInfo(newVideoInfoMap);

    if (successfulResults.length === 0) return sources[0];

    const validSpeeds = successfulResults
      .map((result) => {
        const speedStr = result.testResult.loadSpeed;
        if (speedStr === '未知' || speedStr === '测量中...') return 0;
        const match = speedStr.match(/^([\d.]+)\s*(KB\/s|MB\/s)$/);
        if (!match) return 0;
        const value = parseFloat(match[1]);
        const unit = match[2];
        return unit === 'MB/s' ? value * 1024 : value;
      })
      .filter((speed) => speed > 0);

    const maxSpeed = validSpeeds.length > 0 ? Math.max(...validSpeeds) : 1024;

    const validPings = successfulResults
      .map((result) => result.testResult.pingTime)
      .filter((ping) => ping > 0);

    const minPing = validPings.length > 0 ? Math.min(...validPings) : 50;
    const maxPing = validPings.length > 0 ? Math.max(...validPings) : 1000;

    const resultsWithScore = successfulResults.map((result) => ({
      ...result,
      score: calculateSourceScore(result.testResult, maxSpeed, minPing, maxPing),
    }));

    resultsWithScore.sort((a, b) => b.score - a.score);
    return resultsWithScore[0].source;
  };

  const calculateSourceScore = (
    testResult: { quality: string; loadSpeed: string; pingTime: number; },
    maxSpeed: number, minPing: number, maxPing: number
  ): number => {
    let score = 0;

    const qualityScore = (() => {
      switch (testResult.quality) {
        case '4K': return 100;
        case '2K': return 85;
        case '1080p': return 75;
        case '720p': return 60;
        case '480p': return 40;
        case 'SD': return 20;
        default: return 0;
      }
    })();
    score += qualityScore * 0.4;

    const speedScore = (() => {
      const speedStr = testResult.loadSpeed;
      if (speedStr === '未知' || speedStr === '测量中...') return 30;
      const match = speedStr.match(/^([\d.]+)\s*(KB\/s|MB\/s)$/);
      if (!match) return 30;
      const value = parseFloat(match[1]);
      const unit = match[2];
      const speedKBps = unit === 'MB/s' ? value * 1024 : value;
      const speedRatio = speedKBps / maxSpeed;
      return Math.min(100, Math.max(0, speedRatio * 100));
    })();
    score += speedScore * 0.4;

    const pingScore = (() => {
      const ping = testResult.pingTime;
      if (ping <= 0) return 0;
      if (maxPing === minPing) return 100;
      const pingRatio = (maxPing - ping) / (maxPing - minPing);
      return Math.min(100, Math.max(0, pingRatio * 100));
    })();
    score += pingScore * 0.2;

    return Math.round(score * 100) / 100;
  };

  const updateVideoUrl = (detailData: SearchResult | null, episodeIndex: number) => {
    if (!detailData || !detailData.episodes || episodeIndex >= detailData.episodes.length) {
      setVideoUrl('');
      return;
    }
    const newUrl = detailData?.episodes[episodeIndex] || '';
    if (newUrl !== videoUrl) setVideoUrl(newUrl);
  };

  const ensureVideoSource = (video: HTMLVideoElement | null, url: string) => {
    if (!video || !url) return;
    const sources = Array.from(video.getElementsByTagName('source'));
    const existed = sources.some((s) => s.src === url);
    if (!existed) {
      sources.forEach((s) => s.remove());
      const sourceEl = document.createElement('source');
      sourceEl.src = url;
      video.appendChild(sourceEl);
    }
    video.disableRemotePlayback = false;
    if (video.hasAttribute('disableRemotePlayback')) {
      video.removeAttribute('disableRemotePlayback');
    }
  };

  const requestWakeLock = async () => {
    try {
      if ('wakeLock' in navigator) {
        wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
      }
    } catch (_err) {
      console.debug('Wake Lock 请求失败或未受支持');
    }
  };

  const releaseWakeLock = async () => {
    try {
      if (wakeLockRef.current) {
        await wakeLockRef.current.release();
        wakeLockRef.current = null;
      }
    } catch (_err) {
      console.debug('Wake Lock 释放失败');
    }
  };

  // 清理播放器资源的统一函数 (兼容版)
  const cleanupPlayer = () => {
    if (artPlayerRef.current) {
      try {
        const art = artPlayerRef.current;
        // 兼容获取原生 video 节点
        const video = art.video || art.template?.$video;

        if (video) {

          // 🛑 移动端致命补丁 1：先静音并归零，瞬间切断锁屏音频
          video.muted = true;
          video.currentTime = 0;
          video.pause();

          // 🛑 移动端致命补丁 2：清空 Safari 原生 HLS 的嵌套节点
          while (video.firstChild) {
            video.removeChild(video.firstChild);
          }

          // 彻底移除数据源并强迫内核重载空内容
          video.removeAttribute('src');
          video.removeAttribute('srcObject');
          video.load();

          // 清理第三方 HLS 实例
          const hls = video.hls || art.hls;
          if (hls) {
            hls.stopLoad();
            hls.detachMedia();
            hls.destroy();
            video.hls = null;
            art.hls = null;
          }

          // ==========================================
          // 🛑 移动端致命补丁 3：暴力拔除 DOM 节点
          // 不要等 React 虚拟 DOM 或 ArtPlayer 来慢吞吞地销毁！
          // 在系统回过神来之前，直接手动从真实 DOM 树上斩断引用
          // ==========================================
          if (video.parentNode) {
            video.parentNode.removeChild(video);
          }
        }

        // 最后由框架进行常规的包裹节点清理
        art.destroy(true);
        artPlayerRef.current = null;
        
        console.debug('✅ [移动端优化版] 播放器资源及DOM节点已彻底拔除');
      } catch (err) {
        console.warn('⚠️ 清理播放器时出现异常，已强制重置引用:', err);
        artPlayerRef.current = null;
      }
    }
  };

  const formatTime = (seconds: number): string => {
    if (seconds === 0) return '00:00';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = Math.round(seconds % 60);

    if (hours === 0) {
      return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    } else {
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
  };

  // 【核心修复】：真正的云端配置同步器
  const handleSkipConfigChange = async (newConfig: {
    enable: boolean;
    intro_time: number;
    outro_time: number;
  }) => {
    if (!currentSourceRef.current || !currentIdRef.current) return;

    try {
      setSkipConfig(newConfig);

      // 云端持久化存储
      if (!newConfig.enable && !newConfig.intro_time && !newConfig.outro_time) {
        await deleteSkipConfig(currentSourceRef.current, currentIdRef.current);
      } else {
        await saveSkipConfig(currentSourceRef.current, currentIdRef.current, newConfig);
      }

      // 同步更新播放器面板 UI 状态
      if (artPlayerRef.current && artPlayerRef.current.setting) {
        artPlayerRef.current.setting.update({
          name: '跳过片头片尾',
          switch: newConfig.enable,
        });
        artPlayerRef.current.setting.update({
          name: '设置片头',
          tooltip: newConfig.intro_time > 0 ? formatTime(newConfig.intro_time) : '设置片头时间',
        });
        artPlayerRef.current.setting.update({
          name: '设置片尾',
          tooltip: newConfig.outro_time < 0 ? `-${formatTime(-newConfig.outro_time)}` : '设置片尾时间',
        });
      }

      console.log('跳过配置已同步:', newConfig);
    } catch (_err) {
      console.debug('保存跳过配置失败');
    }
  };

  class CustomHlsJsLoader extends Hls.DefaultConfig.loader {
    constructor(config: any) {
      super(config);
      const load = this.load.bind(this);
      this.load = function (context: any, config: any, callbacks: any) {
        if ((context as any).type === 'manifest' || (context as any).type === 'level') {
          const onSuccess = callbacks.onSuccess;
          callbacks.onSuccess = function (response: any, stats: any, context: any) {
            if (response.data && typeof response.data === 'string') {
              try {
                const extra = (process.env.NEXT_PUBLIC_AD_BLOCK_PATTERNS || '')
                  .split(',')
                  .map((x) => x.trim())
                  .filter(Boolean);
                const r = filterAdsFromM3U8(response.data, {
                  baseUrl: context?.url,
                  extraPatterns: extra,
                });
                if (r.removedSegments > 0) {
                  console.info(`[去广告] 已移除 ${r.removedSegments} 个分片（约 ${r.removedSeconds.toFixed(1)} 秒）`);
                } else if (r.skippedReason && r.skippedReason !== 'not-media-playlist') {
                  console.debug(`[去广告] 未过滤：${r.skippedReason}`);
                }
                response.data = r.content;
              } catch {
                // 过滤出错时保持原始列表
              }
            }
            return onSuccess(response, stats, context, null);
          };
        }
        load(context, config, callbacks);
      };
    }
  }

  useEffect(() => {
    updateVideoUrl(detail, currentEpisodeIndex);
  }, [detail, currentEpisodeIndex]);

  useEffect(() => {
    const fetchSourceDetail = async (source: string, id: string): Promise<SearchResult[]> => {
      try {
        const detailResponse = await fetch(`/api/detail?source=${source}&id=${id}`);
        if (!detailResponse.ok) throw new Error('获取详情失败');
        const detailData = (await detailResponse.json()) as SearchResult;
        setAvailableSources([detailData]);
        return [detailData];
      } catch (_err) {
        return [];
      } finally {
        setSourceSearchLoading(false);
      }
    };

    const fetchSourcesData = async (query: string): Promise<SearchResult[]> => {
      try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(query.trim())}`);
        if (!response.ok) throw new Error('搜索失败');
        const data = await response.json();
        const results = data.results.filter(
          (result: SearchResult) =>
            result.title.replaceAll(' ', '').toLowerCase() === videoTitleRef.current.replaceAll(' ', '').toLowerCase() &&
            (videoYearRef.current ? result.year.toLowerCase() === videoYearRef.current.toLowerCase() : true) &&
            (searchType ? (searchType === 'tv' && result.episodes.length > 1) || (searchType === 'movie' && result.episodes.length === 1) : true)
        );
        setAvailableSources(results);
        return results;
      } catch (err) {
        setSourceSearchError(err instanceof Error ? err.message : '搜索失败');
        setAvailableSources([]);
        return [];
      } finally {
        setSourceSearchLoading(false);
      }
    };

    const initAll = async () => {
      if (!currentSource && !currentId && !videoTitle && !searchTitle) {
        setError('缺少必要参数');
        setLoading(false);
        return;
      }
      setLoading(true);
      setLoadingStage(currentSource && currentId ? 'fetching' : 'searching');
      setLoadingMessage(currentSource && currentId ? '🎬 正在获取视频详情...' : '🔍 正在搜索播放源...');

      let sourcesInfo = await fetchSourcesData(searchTitle || videoTitle);
      if (currentSource && currentId && !sourcesInfo.some((s) => s.source === currentSource && s.id === currentId)) {
        sourcesInfo = await fetchSourceDetail(currentSource, currentId);
      }
      if (sourcesInfo.length === 0) {
        setError('未找到匹配结果');
        setLoading(false);
        return;
      }

      let detailData: SearchResult = sourcesInfo[0];
      if (currentSource && currentId && !needPreferRef.current) {
        const target = sourcesInfo.find((s) => s.source === currentSource && s.id === currentId);
        if (target) {
          detailData = target;
        } else {
          setError('未找到匹配结果');
          setLoading(false);
          return;
        }
      }

      if ((!currentSource || !currentId || needPreferRef.current) && optimizationEnabled) {
        setLoadingStage('preferring');
        setLoadingMessage('⚡ 正在优选最佳播放源...');
        detailData = await preferBestSource(sourcesInfo);
      }

      setNeedPrefer(false);
      setCurrentSource(detailData.source);
      setCurrentId(detailData.id);
      setVideoYear(detailData.year);
      setVideoTitle(detailData.title || videoTitleRef.current);
      setVideoCover(detailData.poster);
      setVideoDoubanId(detailData.douban_id || 0);
      setDetail(detailData);
      
      if (currentEpisodeIndex >= detailData.episodes.length) {
        setCurrentEpisodeIndex(0);
      }

      const newUrl = new URL(window.location.href);
      newUrl.searchParams.set('source', detailData.source);
      newUrl.searchParams.set('id', detailData.id);
      newUrl.searchParams.set('year', detailData.year);
      newUrl.searchParams.set('title', detailData.title);
      newUrl.searchParams.delete('prefer');
      window.history.replaceState({}, '', newUrl.toString());

      setLoadingStage('ready');
      setLoadingMessage('✨ 准备就绪，即将开始播放...');
      setTimeout(() => setLoading(false), 1000);
    };

    initAll();
  }, []);

  useEffect(() => {
    const initFromHistory = async () => {
      if (!currentSource || !currentId) return;
      try {
        const allRecords = await getAllPlayRecords();
        const key = generateStorageKey(currentSource, currentId);
        const record = allRecords[key];
        if (record) {
          if (record.index - 1 !== currentEpisodeIndex) {
            setCurrentEpisodeIndex(record.index - 1);
          }
          resumeTimeRef.current = record.play_time;
        }
      } catch (_err) {
        console.debug('读取历史进度失败');
      }
    };
    initFromHistory();
  }, []);

  // 【核心修复】：从数据库层拉取远端配置
  useEffect(() => {
    const initSkipConfig = async () => {
      if (!currentSource || !currentId) return;
      try {
        const config = await getSkipConfig(currentSource, currentId);
        if (config) {
          setSkipConfig(config);
        } else {
          // 确保切换电影时恢复默认状态
          setSkipConfig({ enable: false, intro_time: 0, outro_time: 0 });
        }
      } catch (_err) {
        console.debug('读取云端跳过配置失败');
      }
    };
    initSkipConfig();
  }, [currentSource, currentId]);

  const handleSourceChange = async (newSource: string, newId: string, newTitle: string) => {
    try {
      setVideoLoadingStage('sourceChanging');
      setIsVideoLoading(true);

      const currentPlayTime = artPlayerRef.current?.currentTime || 0;

      if (currentSourceRef.current && currentIdRef.current) {
        try {
          await deletePlayRecord(currentSourceRef.current, currentIdRef.current);
          
          // 换源时平滑迁移跳过配置
          await deleteSkipConfig(currentSourceRef.current, currentIdRef.current);
          await saveSkipConfig(newSource, newId, skipConfigRef.current);
        } catch (_err) {
          console.debug('清除旧源数据记录失败');
        }
      }

      const newDetail = availableSources.find((s) => s.source === newSource && s.id === newId);
      if (!newDetail) {
        setError('未找到匹配结果');
        return;
      }

      let targetIndex = currentEpisodeIndex;
      if (!newDetail.episodes || targetIndex >= newDetail.episodes.length) targetIndex = 0;

      if (targetIndex !== currentEpisodeIndex) {
        resumeTimeRef.current = 0;
      } else if ((!resumeTimeRef.current || resumeTimeRef.current === 0) && currentPlayTime > 1) {
        resumeTimeRef.current = currentPlayTime;
      }

      const newUrl = new URL(window.location.href);
      newUrl.searchParams.set('source', newSource);
      newUrl.searchParams.set('id', newId);
      newUrl.searchParams.set('year', newDetail.year);
      window.history.replaceState({}, '', newUrl.toString());

      setVideoTitle(newDetail.title || newTitle);
      setVideoYear(newDetail.year);
      setVideoCover(newDetail.poster);
      setVideoDoubanId(newDetail.douban_id || 0);
      setCurrentSource(newSource);
      setCurrentId(newId);
      setDetail(newDetail);
      setCurrentEpisodeIndex(targetIndex);
    } catch (err) {
      setIsVideoLoading(false);
      setError(err instanceof Error ? err.message : '换源失败');
    }
  };

  useEffect(() => {
    document.addEventListener('keydown', handleKeyboardShortcuts);
    return () => document.removeEventListener('keydown', handleKeyboardShortcuts);
  }, []);

  const handleEpisodeChange = (episodeNumber: number) => {
    if (episodeNumber >= 0 && episodeNumber < totalEpisodes) {
      if (artPlayerRef.current && artPlayerRef.current.paused) saveCurrentPlayProgress();
      setCurrentEpisodeIndex(episodeNumber);
    }
  };

  const handlePreviousEpisode = () => {
    const d = detailRef.current;
    const idx = currentEpisodeIndexRef.current;
    if (d && d.episodes && idx > 0) {
      if (artPlayerRef.current && !artPlayerRef.current.paused) saveCurrentPlayProgress();
      setCurrentEpisodeIndex(idx - 1);
    }
  };

  const handleNextEpisode = () => {
    const d = detailRef.current;
    const idx = currentEpisodeIndexRef.current;
    if (d && d.episodes && idx < d.episodes.length - 1) {
      if (artPlayerRef.current && !artPlayerRef.current.paused) saveCurrentPlayProgress();
      setCurrentEpisodeIndex(idx + 1);
    }
  };

  const handleKeyboardShortcuts = (e: KeyboardEvent) => {
    if ((e.target as HTMLElement).tagName === 'INPUT' || (e.target as HTMLElement).tagName === 'TEXTAREA') return;
    if (e.altKey && e.key === 'ArrowLeft') {
      if (detailRef.current && currentEpisodeIndexRef.current > 0) {
        handlePreviousEpisode();
        e.preventDefault();
      }
    }
    if (e.altKey && e.key === 'ArrowRight') {
      const d = detailRef.current;
      const idx = currentEpisodeIndexRef.current;
      if (d && idx < d.episodes.length - 1) {
        handleNextEpisode();
        e.preventDefault();
      }
    }
    if (!e.altKey && e.key === 'ArrowLeft') {
      if (artPlayerRef.current && artPlayerRef.current.currentTime > 5) {
        artPlayerRef.current.currentTime -= 10;
        e.preventDefault();
      }
    }
    if (!e.altKey && e.key === 'ArrowRight') {
      if (artPlayerRef.current && artPlayerRef.current.currentTime < artPlayerRef.current.duration - 5) {
        artPlayerRef.current.currentTime += 10;
        e.preventDefault();
      }
    }
    if (e.key === 'ArrowUp') {
      if (artPlayerRef.current && artPlayerRef.current.volume < 1) {
        artPlayerRef.current.volume = Math.round((artPlayerRef.current.volume + 0.1) * 10) / 10;
        artPlayerRef.current.notice.show = `音量: ${Math.round(artPlayerRef.current.volume * 100)}`;
        e.preventDefault();
      }
    }
    if (e.key === 'ArrowDown') {
      if (artPlayerRef.current && artPlayerRef.current.volume > 0) {
        artPlayerRef.current.volume = Math.round((artPlayerRef.current.volume - 0.1) * 10) / 10;
        artPlayerRef.current.notice.show = `音量: ${Math.round(artPlayerRef.current.volume * 100)}`;
        e.preventDefault();
      }
    }
    if (e.key === ' ') {
      if (artPlayerRef.current) {
        artPlayerRef.current.toggle();
        e.preventDefault();
      }
    }
    if (e.key === 'f' || e.key === 'F') {
      if (artPlayerRef.current) {
        artPlayerRef.current.fullscreen = !artPlayerRef.current.fullscreen;
        e.preventDefault();
      }
    }
  };

  const saveCurrentPlayProgress = async () => {
    if (!artPlayerRef.current || !currentSourceRef.current || !currentIdRef.current || !videoTitleRef.current || !detailRef.current?.source_name) return;
    const player = artPlayerRef.current;
    const currentTime = player.currentTime || 0;
    const duration = player.duration || 0;
    if (currentTime < 1 || !duration) return;

    try {
      await savePlayRecord(currentSourceRef.current, currentIdRef.current, {
        title: videoTitleRef.current,
        source_name: detailRef.current?.source_name || '',
        year: detailRef.current?.year,
        cover: detailRef.current?.poster || '',
        index: currentEpisodeIndexRef.current + 1,
        total_episodes: detailRef.current?.episodes.length || 1,
        play_time: Math.floor(currentTime),
        total_time: Math.floor(duration),
        save_time: Date.now(),
        search_title: searchTitle,
      });
      lastSaveTimeRef.current = Date.now();
    } catch (_err) {
      console.debug('保存播放进度失败');
    }
  };

  useEffect(() => {
    const handleBeforeUnload = () => {
      saveCurrentPlayProgress();
      releaseWakeLock();
      cleanupPlayer();
    };
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        saveCurrentPlayProgress();
        releaseWakeLock();
      } else if (document.visibilityState === 'visible') {
        if (artPlayerRef.current && !artPlayerRef.current.paused) requestWakeLock();
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [currentEpisodeIndex, detail, artPlayerRef.current]);

  useEffect(() => {
    if (!currentSource || !currentId) return;
    (async () => {
      try {
        const fav = await isFavorited(currentSource, currentId);
        setFavorited(fav);
      } catch (_err) {
        console.debug('获取收藏状态失败');
      }
    })();
  }, [currentSource, currentId]);

  useEffect(() => {
    if (!currentSource || !currentId) return;
    const unsubscribe = subscribeToDataUpdates('favoritesUpdated', (favorites: Record<string, any>) => {
      const key = generateStorageKey(currentSource, currentId);
      setFavorited(!!favorites[key]);
    });
    return unsubscribe;
  }, [currentSource, currentId]);

  const handleToggleFavorite = async () => {
    if (!videoTitleRef.current || !detailRef.current || !currentSourceRef.current || !currentIdRef.current) return;
    try {
      if (favorited) {
        await deleteFavorite(currentSourceRef.current, currentIdRef.current);
        setFavorited(false);
      } else {
        await saveFavorite(currentSourceRef.current, currentIdRef.current, {
          title: videoTitleRef.current,
          source_name: detailRef.current?.source_name || '',
          year: detailRef.current?.year,
          cover: detailRef.current?.poster || '',
          total_episodes: detailRef.current?.episodes.length || 1,
          save_time: Date.now(),
          search_title: searchTitle,
        });
        setFavorited(true);
      }
    } catch (_err) {
      console.debug('切换收藏失败');
    }
  };

  useEffect(() => {
    if (!Artplayer || !Hls || !videoUrl || loading || currentEpisodeIndex === null || !artRef.current) return;

    if (!detail || !detail.episodes || currentEpisodeIndex >= detail.episodes.length || currentEpisodeIndex < 0) {
      setError(`选集索引无效，当前共 ${totalEpisodes} 集`);
      return;
    }

    if (!videoUrl) {
      setError('视频地址无效');
      return;
    }

    const isWebkit = typeof window !== 'undefined' && typeof (window as any).webkitConvertPointFromNodeToPage === 'function';

    if (!isWebkit && artPlayerRef.current) {
      artPlayerRef.current.switch = videoUrl;
      artPlayerRef.current.title = `${videoTitle} - 第${currentEpisodeIndex + 1}集`;
      artPlayerRef.current.poster = videoCover;
      if (artPlayerRef.current?.video) {
        ensureVideoSource(artPlayerRef.current.video as HTMLVideoElement, videoUrl);
      }
      return;
    }

    if (artPlayerRef.current) cleanupPlayer();

    try {
      Artplayer.PLAYBACK_RATE = [0.5, 0.75, 1, 1.25, 1.5, 2, 3];
      Artplayer.USE_RAF = false;
      Artplayer.FULLSCREEN_WEB_IN_BODY = true;

      artPlayerRef.current = new Artplayer({
        container: artRef.current,
        url: videoUrl,
        poster: videoCover,
        volume: 0.7,
        isLive: false,
        muted: false,
        autoplay: true,
        pip: true,
        autoSize: false,
        autoMini: false,
        screenshot: false,
        setting: true,
        loop: false,
        flip: false,
        playbackRate: true,
        aspectRatio: false,
        fullscreen: true,
        fullscreenWeb: true,
        subtitleOffset: false,
        miniProgressBar: false,
        mutex: true,
        playsInline: true,
        autoPlayback: false,
        airplay: true,
        theme: '#22c55e',
        lang: 'zh-cn',
        hotkey: false,
        fastForward: true,
        autoOrientation: true,
        lock: true,
        moreVideoAttr: { crossOrigin: 'anonymous' },
        customType: {
          m3u8: function (video: HTMLVideoElement, url: string) {
            if (!Hls) return;
            if (video.hls) video.hls.destroy();

            const hls = new Hls({
              debug: false,
              enableWorker: true,
              lowLatencyMode: false,
              maxBufferLength: 60,
              maxMaxBufferLength: 120,
              backBufferLength: 30,
              maxBufferSize: 100 * 1000 * 1000,
              loader: blockAdEnabledRef.current ? CustomHlsJsLoader : Hls.DefaultConfig.loader,
            });

            hls.loadSource(url);
            hls.attachMedia(video);
            video.hls = hls;

            ensureVideoSource(video, url);

            hls.on(Hls.Events.ERROR, function (event: any, data: any) {
              if (data.fatal) {
                switch (data.type) {
                  case Hls.ErrorTypes.NETWORK_ERROR:
                    hls.startLoad();
                    break;
                  case Hls.ErrorTypes.MEDIA_ERROR:
                    hls.recoverMediaError();
                    break;
                  default:
                    hls.destroy();
                    break;
                }
              }
            });
          },
        },
        icons: {
          loading: '<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1MCIgaGVpZ2h0PSI1MCIgdmlld0JveD0iMCAwIDUwIDUwIj48cGF0aCBkPSJNMjUuMjUxIDYuNDYxYy0xMC4zMTggMC0xOC42ODMgOC4zNjUtMTguNjgzIDE4LjY4M2g0LjA2OGMwLTguMDcgNi41NDUtMTQuNjE1IDE0LjYxNS0xNC42MTVWNi40NjF6IiBmaWxsPSIjMDA5Njg4Ij48YW5pbWF0ZVRyYW5zZm9ybSBhdHRyaWJ1dGVOYW1lPSJ0cmFuc2Zvcm0iIGF0dHJpYnV0ZVR5cGU9IlhNTCIgZHVyPSIxcyIgZnJvbT0iMCAyNSAyNSIgcmVwZWF0Q291bnQ9ImluZGVmaW5pdGUiIHRvPSIzNjAgMjUgMjUiIHR5cGU9InJvdGF0ZSIvPjwvcGF0aD48L3N2Zz4=">',
        },
        settings: [
          {
            html: '去广告',
            icon: '<text x="50%" y="50%" font-size="20" font-weight="bold" text-anchor="middle" dominant-baseline="middle" fill="#ffffff">AD</text>',
            tooltip: blockAdEnabled ? '已开启' : '已关闭',
            onClick() {
              const newVal = !blockAdEnabled;
              try {
                localStorage.setItem('enable_blockad', String(newVal));
                if (artPlayerRef.current) {
                  resumeTimeRef.current = artPlayerRef.current.currentTime;
                  if (artPlayerRef.current.video?.hls) {
                    artPlayerRef.current.video.hls.destroy();
                  }
                  artPlayerRef.current.destroy();
                  artPlayerRef.current = null;
                }
                setBlockAdEnabled(newVal);
              } catch (_err) {
                console.debug('去广告状态切换出错');
              }
              return newVal ? '当前开启' : '当前关闭';
            },
          },
          {
            name: '跳过片头片尾',
            html: '跳过片头片尾',
            switch: skipConfigRef.current.enable,
            onSwitch: function (item) {
              const newConfig = { ...skipConfigRef.current, enable: !item.switch };
              handleSkipConfigChange(newConfig);
              return !item.switch;
            },
          },
          {
            html: '删除跳过配置',
            onClick: function () {
              handleSkipConfigChange({ enable: false, intro_time: 0, outro_time: 0 });
              return '';
            },
          },
          {
            name: '设置片头',
            html: '设置片头',
            icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="5" cy="12" r="2" fill="#ffffff"/><path d="M9 12L17 12" stroke="#ffffff" stroke-width="2"/><path d="M17 6L17 18" stroke="#ffffff" stroke-width="2"/></svg>',
            tooltip: skipConfigRef.current.intro_time === 0 ? '设置片头时间' : `${formatTime(skipConfigRef.current.intro_time)}`,
            onClick: function () {
              const currentTime = artPlayerRef.current?.currentTime || 0;
              if (currentTime > 0) {
                // 点击设置时，自动将总开关打开
                handleSkipConfigChange({ ...skipConfigRef.current, intro_time: currentTime, enable: true });
                return `${formatTime(currentTime)}`;
              }
            },
          },
          {
            name: '设置片尾',
            html: '设置片尾',
            icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 6L7 18" stroke="#ffffff" stroke-width="2"/><path d="M7 12L15 12" stroke="#ffffff" stroke-width="2"/><circle cx="19" cy="12" r="2" fill="#ffffff"/></svg>',
            tooltip: skipConfigRef.current.outro_time >= 0 ? '设置片尾时间' : `-${formatTime(-skipConfigRef.current.outro_time)}`,
            onClick: function () {
              const outroTime = -(artPlayerRef.current?.duration - artPlayerRef.current?.currentTime) || 0;
              if (outroTime < 0) {
                // 点击设置时，自动将总开关打开
                handleSkipConfigChange({ ...skipConfigRef.current, outro_time: outroTime, enable: true });
                return `-${formatTime(-outroTime)}`;
              }
            },
          },
        ],
        controls: [
          {
            position: 'left',
            index: 13,
            html: '<i class="art-icon flex"><svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z" fill="currentColor"/></svg></i>',
            tooltip: '播放下一集',
            click: function () { handleNextEpisode(); },
          },
        ],
      });

      artPlayerRef.current.on('ready', () => {
        setError(null);
        if (artPlayerRef.current && !artPlayerRef.current.paused) requestWakeLock();
      });

      artPlayerRef.current.on('play', () => requestWakeLock());
      artPlayerRef.current.on('pause', () => { releaseWakeLock(); saveCurrentPlayProgress(); });

      if (artPlayerRef.current && !artPlayerRef.current.paused) requestWakeLock();

      artPlayerRef.current.on('video:volumechange', () => { lastVolumeRef.current = artPlayerRef.current.volume; });
      artPlayerRef.current.on('video:ratechange', () => { lastPlaybackRateRef.current = artPlayerRef.current.playbackRate; });

      artPlayerRef.current.on('video:canplay', () => {
        if (resumeTimeRef.current && resumeTimeRef.current > 0) {
          try {
            const duration = artPlayerRef.current.duration || 0;
            let target = resumeTimeRef.current;
            if (duration && target >= duration - 2) target = Math.max(0, duration - 5);
            artPlayerRef.current.currentTime = target;
          } catch (_err) {
            console.debug('恢复播放进度失败');
          }
        }
        resumeTimeRef.current = null;

        setTimeout(() => {
          if (Math.abs(artPlayerRef.current.volume - lastVolumeRef.current) > 0.01) {
            artPlayerRef.current.volume = lastVolumeRef.current;
          }
          if (Math.abs(artPlayerRef.current.playbackRate - lastPlaybackRateRef.current) > 0.01 && isWebkit) {
            artPlayerRef.current.playbackRate = lastPlaybackRateRef.current;
          }
          artPlayerRef.current.notice.show = '';
        }, 0);

        setIsVideoLoading(false);
      });

      // =========================================================================
      // 【核心防跳逻辑修复区域】
      // =========================================================================
      artPlayerRef.current.on('video:timeupdate', () => {
        const player = artPlayerRef.current;
        if (!player) return;

        const currentTime = player.currentTime || 0;
        const duration = player.duration || 0;

        // 1. 播放进度保存
        const now = Date.now();
        const interval = process.env.NEXT_PUBLIC_STORAGE_TYPE === 'upstash' ? 20000 : 5000;
        if (now - lastSaveTimeRef.current > interval) {
          saveCurrentPlayProgress();
          lastSaveTimeRef.current = now;
        }

        // 全局开关
        if (!skipConfigRef.current.enable) return;

        // 【防御 1】：挂起跳转期间的校验
        if (resumeTimeRef.current && resumeTimeRef.current > 0) return;

        const introTime = skipConfigRef.current.intro_time;
        const outroTime = skipConfigRef.current.outro_time; // 负数

        // 【防御 2】：HLS 幽灵锁 - 防止 currentTime 突然归零但真实进度已经越过了片头
        // 只有在视频已就绪、未在 seeking 时才执行跳过动作
        if (introTime > 0) {
          if (currentTime < introTime && !hasSkippedIntroRef.current) {
            if (player.video && !player.video.seeking && player.video.readyState >= 1) {
              player.currentTime = introTime;
              player.notice.show = `已自动跳过片头 (${formatTime(introTime)})`;
            }
          } else if (currentTime >= introTime && !hasSkippedIntroRef.current) {
            // 当真实播放进度越过片头后锁定标记，避免手动拖动回片头被弹飞
            hasSkippedIntroRef.current = true;
          }
        }

        // 【防御 3】：片尾跳过修复
        if (outroTime < 0) {
          if (
            duration > Math.abs(outroTime) &&
            currentTime >= duration + outroTime &&
            !hasSkippedOutroRef.current
          ) {
            const d = detailRef.current;
            const idx = currentEpisodeIndexRef.current;
            if (d && d.episodes && idx < d.episodes.length - 1 && !player.paused) {
              hasSkippedOutroRef.current = true;
              player.notice.show = `已自动跳过片尾 (${formatTime(outroTime)})，即将播放下一集`;
              player.pause();
              setCurrentEpisodeIndex(idx + 1);
              return;
            }
          }
        }
      });
      // =========================================================================

      artPlayerRef.current.on('error', (_err: any) => {
        if (artPlayerRef.current.currentTime > 0) return;
      });

      artPlayerRef.current.on('video:ended', () => {
        releaseWakeLock();
        const d = detailRef.current;
        const idx = currentEpisodeIndexRef.current;
        if (d && d.episodes && idx < d.episodes.length - 1) {
          setTimeout(() => setCurrentEpisodeIndex(idx + 1), 1000);
        }
      });

      if (artPlayerRef.current?.video) {
        ensureVideoSource(artPlayerRef.current.video as HTMLVideoElement, videoUrl);
      }
    } catch (_err) {
      setError('播放器初始化失败');
    }
  }, [Artplayer, Hls, videoUrl, loading, blockAdEnabled]);

  useEffect(() => {
    return () => {
      if (saveIntervalRef.current) clearInterval(saveIntervalRef.current);
      releaseWakeLock();
      cleanupPlayer();
    };
  }, []);

  if (loading) {
    return (
      <PageLayout activePath='/play'>
        <div className='flex items-center justify-center min-h-screen bg-transparent'>
          <div className='text-center max-w-md mx-auto px-6'>
            <div className='relative mb-8'>
              <div className='relative mx-auto w-24 h-24 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl shadow-2xl flex items-center justify-center transform hover:scale-105 transition-transform duration-300'>
                <div className='text-white text-4xl'>
                  {loadingStage === 'searching' && '🔍'}
                  {loadingStage === 'preferring' && '⚡'}
                  {loadingStage === 'fetching' && '🎬'}
                  {loadingStage === 'ready' && '✨'}
                </div>
                <div className='absolute -inset-2 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl opacity-20 animate-spin'></div>
              </div>
              <div className='absolute top-0 left-0 w-full h-full pointer-events-none'>
                <div className='absolute top-2 left-2 w-2 h-2 bg-green-400 rounded-full animate-bounce'></div>
                <div className='absolute top-4 right-4 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce' style={{ animationDelay: '0.5s' }}></div>
                <div className='absolute bottom-3 left-6 w-1 h-1 bg-lime-400 rounded-full animate-bounce' style={{ animationDelay: '1s' }}></div>
              </div>
            </div>

            <div className='mb-6 w-80 mx-auto'>
              <div className='flex justify-center space-x-2 mb-4'>
                <div className={`w-3 h-3 rounded-full transition-all duration-500 ${loadingStage === 'searching' || loadingStage === 'fetching' ? 'bg-green-500 scale-125' : loadingStage === 'preferring' || loadingStage === 'ready' ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                <div className={`w-3 h-3 rounded-full transition-all duration-500 ${loadingStage === 'preferring' ? 'bg-green-500 scale-125' : loadingStage === 'ready' ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                <div className={`w-3 h-3 rounded-full transition-all duration-500 ${loadingStage === 'ready' ? 'bg-green-500 scale-125' : 'bg-gray-300'}`}></div>
              </div>
              <div className='w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden'>
                <div className='h-full bg-gradient-to-r from-green-500 to-emerald-600 rounded-full transition-all duration-1000 ease-out' style={{ width: loadingStage === 'searching' || loadingStage === 'fetching' ? '33%' : loadingStage === 'preferring' ? '66%' : '100%' }}></div>
              </div>
            </div>

            <div className='space-y-2'>
              <p className='text-xl font-semibold text-gray-800 dark:text-gray-200 animate-pulse'>
                {loadingMessage}
              </p>
            </div>
          </div>
        </div>
      </PageLayout>
    );
  }

  if (error) {
    return (
      <PageLayout activePath='/play'>
        <div className='flex items-center justify-center min-h-screen bg-transparent'>
          <div className='text-center max-w-md mx-auto px-6'>
            <div className='relative mb-8'>
              <div className='relative mx-auto w-24 h-24 bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl shadow-2xl flex items-center justify-center transform hover:scale-105 transition-transform duration-300'>
                <div className='text-white text-4xl'>😵</div>
                <div className='absolute -inset-2 bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl opacity-20 animate-pulse'></div>
              </div>
              <div className='absolute top-0 left-0 w-full h-full pointer-events-none'>
                <div className='absolute top-2 left-2 w-2 h-2 bg-red-400 rounded-full animate-bounce'></div>
                <div className='absolute top-4 right-4 w-1.5 h-1.5 bg-orange-400 rounded-full animate-bounce' style={{ animationDelay: '0.5s' }}></div>
                <div className='absolute bottom-3 left-6 w-1 h-1 bg-yellow-400 rounded-full animate-bounce' style={{ animationDelay: '1s' }}></div>
              </div>
            </div>

            <div className='space-y-4 mb-8'>
              <h2 className='text-2xl font-bold text-gray-800 dark:text-gray-200'>哎呀，出现了一些问题</h2>
              <div className='bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4'>
                <p className='text-red-600 dark:text-red-400 font-medium'>{error}</p>
              </div>
              <p className='text-sm text-gray-500 dark:text-gray-400'>请检查网络连接或尝试刷新页面</p>
            </div>

            <div className='space-y-3'>
              <button
                onClick={() => videoTitle ? router.push(`/search?q=${encodeURIComponent(videoTitle)}`) : router.back()}
                className='w-full px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl font-medium hover:from-green-600 hover:to-emerald-700 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl'
              >
                {videoTitle ? '🔍 返回搜索' : '← 返回上页'}
              </button>
              <button
                onClick={() => window.location.reload()}
                className='w-full px-6 py-3 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl font-medium hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200'
              >
                🔄 重新尝试
              </button>
            </div>
          </div>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout activePath='/play'>
      <div className='flex flex-col gap-3 py-4 px-5 lg:px-[3rem] 2xl:px-20'>
        <div className='py-1'>
          <h1 className='text-xl font-semibold text-gray-900 dark:text-gray-100'>
            {videoTitle || '影片标题'}
            {totalEpisodes > 1 && (
              <span className='text-gray-500 dark:text-gray-400'>
                {/* 彻底绕过类型检查：使用 any 断言读取 episodes_titles */}
                {` > ${(detail as any)?.episodes_titles?.[currentEpisodeIndex] || `第 ${currentEpisodeIndex + 1} 集`}`}
              </span>
            )}
          </h1>
        </div>

        <div className='space-y-2'>
          <div className='hidden lg:flex justify-end'>
            <button
              onClick={() => setIsEpisodeSelectorCollapsed(!isEpisodeSelectorCollapsed)}
              className='group relative flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-white/80 hover:bg-white dark:bg-gray-800/80 dark:hover:bg-gray-800 backdrop-blur-sm border border-gray-200/50 dark:border-gray-700/50 shadow-sm hover:shadow-md transition-all duration-200'
              title={isEpisodeSelectorCollapsed ? '显示选集面板' : '隐藏选集面板'}
            >
              <svg className={`w-3.5 h-3.5 text-gray-500 dark:text-gray-400 transition-transform duration-200 ${isEpisodeSelectorCollapsed ? 'rotate-180' : 'rotate-0'}`} fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth='2' d='M9 5l7 7-7 7' />
              </svg>
              <span className='text-xs font-medium text-gray-600 dark:text-gray-300'>{isEpisodeSelectorCollapsed ? '显示' : '隐藏'}</span>
              <div className={`absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full transition-all duration-200 ${isEpisodeSelectorCollapsed ? 'bg-orange-400 animate-pulse' : 'bg-green-400'}`}></div>
            </button>
          </div>

          <div className={`grid gap-4 lg:h-[500px] xl:h-[650px] 2xl:h-[750px] transition-all duration-300 ease-in-out ${isEpisodeSelectorCollapsed ? 'grid-cols-1' : 'grid-cols-1 md:grid-cols-4'}`}>
            <div className={`h-full transition-all duration-300 ease-in-out rounded-xl border border-white/0 dark:border-white/30 ${isEpisodeSelectorCollapsed ? 'col-span-1' : 'md:col-span-3'}`}>
              <div className='relative w-full h-[300px] lg:h-full'>
                <div ref={artRef} className='bg-black w-full h-full rounded-xl overflow-hidden shadow-lg'></div>
                {isVideoLoading && (
                  <div className='absolute inset-0 bg-black/85 backdrop-blur-sm rounded-xl flex items-center justify-center z-[500] transition-all duration-300'>
                    <div className='text-center max-w-md mx-auto px-6'>
                      <div className='relative mb-8'>
                        <div className='relative mx-auto w-24 h-24 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl shadow-2xl flex items-center justify-center transform hover:scale-105 transition-transform duration-300'>
                          <div className='text-white text-4xl'>🎬</div>
                          <div className='absolute -inset-2 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl opacity-20 animate-spin'></div>
                        </div>
                        <div className='absolute top-0 left-0 w-full h-full pointer-events-none'>
                          <div className='absolute top-2 left-2 w-2 h-2 bg-green-400 rounded-full animate-bounce'></div>
                          <div className='absolute top-4 right-4 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce' style={{ animationDelay: '0.5s' }}></div>
                          <div className='absolute bottom-3 left-6 w-1 h-1 bg-lime-400 rounded-full animate-bounce' style={{ animationDelay: '1s' }}></div>
                        </div>
                      </div>
                      <div className='space-y-2'>
                        <p className='text-xl font-semibold text-white animate-pulse'>{videoLoadingStage === 'sourceChanging' ? '🔄 切换播放源...' : '🔄 视频加载中...'}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className={`h-[300px] lg:h-full md:overflow-hidden transition-all duration-300 ease-in-out ${isEpisodeSelectorCollapsed ? 'md:col-span-1 lg:hidden lg:opacity-0 lg:scale-95' : 'md:col-span-1 lg:opacity-100 lg:scale-100'}`}>
              <EpisodeSelector
                totalEpisodes={totalEpisodes}
                episodes_titles={(detail as any)?.episodes_titles || []}
                value={currentEpisodeIndex + 1}
                onChange={handleEpisodeChange}
                onSourceChange={handleSourceChange}
                currentSource={currentSource}
                currentId={currentId}
                videoTitle={searchTitle || videoTitle}
                availableSources={availableSources}
                sourceSearchLoading={sourceSearchLoading}
                sourceSearchError={sourceSearchError}
                precomputedVideoInfo={precomputedVideoInfo}
              />
            </div>
          </div>
        </div>

        <div className='grid grid-cols-1 md:grid-cols-4 gap-4'>
          <div className='md:col-span-3'>
            <div className='p-6 flex flex-col min-h-0'>
              <h1 className='text-3xl font-bold mb-2 tracking-wide flex items-center flex-shrink-0 text-center md:text-left w-full'>
                {videoTitle || '影片标题'}
                <button onClick={(e) => { e.stopPropagation(); handleToggleFavorite(); }} className='ml-3 flex-shrink-0 hover:opacity-80 transition-opacity'>
                  <FavoriteIcon filled={favorited} />
                </button>
              </h1>
              <div className='flex flex-wrap items-center gap-3 text-base mb-4 opacity-80 flex-shrink-0'>
                {detail?.class && <span className='text-green-600 font-semibold'>{detail.class}</span>}
                {(detail?.year || videoYear) && <span>{detail?.year || videoYear}</span>}
                {detail?.source_name && <span className='border border-gray-500/60 px-2 py-[1px] rounded'>{detail.source_name}</span>}
                {detail?.type_name && <span>{detail.type_name}</span>}
              </div>
              {detail?.desc && <div className='mt-0 text-base leading-relaxed opacity-90 overflow-y-auto pr-2 flex-1 min-h-0 scrollbar-hide' style={{ whiteSpace: 'pre-line' }}>{detail.desc}</div>}
            </div>
          </div>

          <div className='hidden md:block md:col-span-1 md:order-first'>
            <div className='pl-0 py-4 pr-6'>
              <div className='relative bg-gray-300 dark:bg-gray-700 aspect-[2/3] flex items-center justify-center rounded-xl overflow-hidden'>
                {videoCover ? (
                  <>
                    <img src={processImageUrl(videoCover)} alt={videoTitle} className='w-full h-full object-cover' />
                    {videoDoubanId !== 0 && (
                      <a href={`https://movie.douban.com/subject/${videoDoubanId.toString()}`} target='_blank' rel='noopener noreferrer' className='absolute top-3 left-3'>
                        <div className='bg-green-500 text-white text-xs font-bold w-8 h-8 rounded-full flex items-center justify-center shadow-md hover:bg-green-600 hover:scale-[1.1] transition-all duration-300 ease-out'>
                          <svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'>
                            <path d='M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71'></path>
                            <path d='M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71'></path>
                          </svg>
                        </div>
                      </a>
                    )}
                  </>
                ) : (
                  <span className='text-gray-600 dark:text-gray-400'>封面图片</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  );
}

const FavoriteIcon = ({ filled }: { filled: boolean }) => {
  if (filled) {
    return (
      <svg className='h-7 w-7' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'>
        <path d='M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z' fill='#ef4444' stroke='#ef4444' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round' />
      </svg>
    );
  }
  return <Heart className='h-7 w-7 stroke-[1] text-gray-600 dark:text-gray-300' />;
};

export default function PlayPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <PlayPageClient />
    </Suspense>
  );
}
