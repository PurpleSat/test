// 该文件由 scripts/convert-config.js 自动生成，请勿手动修改
/* eslint-disable */

export const config = {
  "cache_time": 7200,
  "api_site": {
    "dyttzy": {
      "api": "http://caiji.dyttzyapi.com/api.php/provide/vod",
      "name": "电影天堂资源",
      "detail": "http://caiji.dyttzyapi.com"
    },
    "heimuer": {
      "api": "https://json.heimuer.xyz/api.php/provide/vod",
      "name": "黑木耳",
      "detail": "https://heimuer.tv"
    },
    "ruyi": {
      "api": "https://cj.rycjapi.com/api.php/provide/vod",
      "name": "如意资源"
    },
    "bfzy": {
      "api": "https://bfzyapi.com/api.php/provide/vod",
      "name": "暴风资源"
    },
    "tyyszy": {
      "api": "https://tyyszy.com/api.php/provide/vod",
      "name": "天涯资源"
    },
    "ffzy": {
      "api": "http://ffzy5.tv/api.php/provide/vod",
      "name": "非凡影视",
      "detail": "http://ffzy5.tv"
    },
    "zy360": {
      "api": "https://360zy.com/api.php/provide/vod",
      "name": "360资源"
    },
    "maotaizy": {
      "api": "https://caiji.maotaizy.cc/api.php/provide/vod",
      "name": "茅台资源"
    },
    "wolong": {
      "api": "https://wolongzyw.com/api.php/provide/vod",
      "name": "卧龙资源"
    },
    "jisu": {
      "api": "https://jszyapi.com/api.php/provide/vod",
      "name": "极速资源",
      "detail": "https://jszyapi.com"
    },
    "dbzy": {
      "api": "https://dbzy.tv/api.php/provide/vod",
      "name": "豆瓣资源"
    },
    "mozhua": {
      "api": "https://mozhuazy.com/api.php/provide/vod",
      "name": "魔爪资源"
    },
    "mdzy": {
      "api": "https://www.mdzyapi.com/api.php/provide/vod",
      "name": "魔都资源"
    },
    "zuid": {
      "api": "https://api.zuidapi.com/api.php/provide/vod",
      "name": "最大资源"
    },
    "yinghua": {
      "api": "https://m3u8.apiyhzy.com/api.php/provide/vod",
      "name": "樱花资源"
    },
    "wujin": {
      "api": "https://api.wujinapi.me/api.php/provide/vod",
      "name": "无尽资源"
    },
    "ikun": {
      "api": "https://ikunzyapi.com/api.php/provide/vod",
      "name": "iKun资源"
    },
    "lzi": {
      "api": "https://cj.lziapi.com/api.php/provide/vod",
      "name": "量子资源站"
    },
    "aiqiyi": {
      "api": "https://iqiyizyapi.com/api.php/provide/vod",
      "name": "爱奇艺"
    },
    "guangshu": {
      "api": "https://api.guangsuapi.com/api.php/provide/vod",
      "name": "光速资源"
    },
    "huya": {
      "api": "https://www.huyaapi.com/api.php/provide/vod/at/json",
      "name": "虎牙资源"
    },
    "shanhai": {
      "api": "https://zy.sh0o.cn/api.php/provide/vod",
      "name": "山海资源"
    },
    "tianya": {
      "api": "https://tyyszy.com/api.php/provide/vod",
      "name": "天涯影视"
    },
    "piaoling": {
      "api": "https://p2100.net/api.php/provide/vod",
      "name": "飘零资源"
    },
    "uku": {
      "api": "https://api.ukuapi88.com/api.php/provide/vod",
      "name": "U酷影视"
    },
    "shandian": {
      "api": "https://xsd.sdzyapi.com/api.php/provide/vod",
      "name": "闪电资源"
    },
    "jinying": {
      "api": "https://jyzyapi.com/provide/vod/from/jinyingyun/at/json",
      "name": "金鹰资源"
    },
    "subo": {
      "api": "https://subocaiji.com/api.php/provide/vod",
      "name": "速播资源"
    },
    "haohua": {
      "api": "https://hhzyapi.com/api.php/provide/vod",
      "name": "豪华资源"
    },
    "suoni": {
      "api": "https://suoniapi.com/api.php/provide/vod",
      "name": "索尼资源"
    },
    "hongniu": {
      "api": "https://www.hongniuzy2.com/api.php/provide/vod",
      "name": "红牛资源"
    },
    "maoyan": {
      "api": "https://api.maoyanapi.top/api.php/provide/vod",
      "name": "猫眼资源"
    },
    "kuaiche": {
      "api": "https://caiji.kuaichezy.org/api.php/provide/vod",
      "name": "快车资源"
    },
    "youzhi": {
      "api": "https://api.yzzy-api.com/inc/apijson.php",
      "name": "优质资源"
    }
  }
} as const;

export type RuntimeConfig = typeof config;

export default config;
